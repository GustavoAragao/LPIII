class Main {
  public static void main(String[] args) {
    Data data = new Data();

    data.setData(22, 2, 2022);
    data.mostraData();
    data.mostraDataExtenso();
    System.out.println("Tá funfano! :)");
  }
}